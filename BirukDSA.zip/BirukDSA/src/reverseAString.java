import java.util.Stack;

public class reverseAString {
    public reverseAString(String inputString) {
    }

    public class StringReverser {
        public static String reverseStringUsingStack(String s) {
            Stack<Character> stack = new Stack<>();

            for (int i = 0; i < s.length(); i++) {
                stack.push(s.charAt(i));
            }

            StringBuilder reversedString = new StringBuilder();
            while (!stack.isEmpty()) {
                reversedString.append(stack.pop());
            }

            return reversedString.toString();
        }
    }
    public static void main(String[] args) {
        String inputString = "Hello";
        String reversedString = new reverseAString(inputString).toString();
        System.out.println(inputString);
        System.out.println(reversedString);
    }
}
