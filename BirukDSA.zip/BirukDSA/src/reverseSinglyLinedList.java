public class reverseSinglyLinedList {

    class Node {
        int value;
        Node next;
        Node (int value) {
            this.value = value;
            this.next = null;
        }
    }
    private Node head;
    private Node tail;
    private int length;
    public reverseSinglyLinedList(int value){
        Node newNode = new Node(value);
        head = newNode;
        tail = newNode;
        length = 1;
    }
    public void reverse() {
        Node current = head;
        head = tail;
        tail = current;

        Node after = current.next;
        Node before = null;
        while (current != null) {
            after = current.next;
            current.next = before;
            before = current;
            current = after;
        }
    }
}
